package io.kestra.plugin.overscore.lists.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
	
public class ConnectionManager {
		
    private static ConnectionManager instance;
    private static final String URL = "jdbc:postgresql://julianomiranda.site:5432/kestra";
    private static final String USER = "kestra";
    private static final String PASSWORD = "k3str4";
    private static final String SCHEMA = "FRAUDE";

    private ConnectionManager() {}

    public static synchronized ConnectionManager getInstance() {
        if (instance == null) {
            instance = new ConnectionManager();
        }
        return instance;
    }

    public Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
        
        // Define o schema default após abrir a conexão
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("SET search_path TO " + SCHEMA);
        }

        return connection;
    }	
}
