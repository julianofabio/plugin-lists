package io.kestra.plugin.overscore.lists.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import io.kestra.plugin.overscore.lists.config.ConnectionManager;
import io.kestra.plugin.overscore.lists.dao.FraudeDAO;
import io.kestra.plugin.overscore.lists.model.Fraude;

public class FraudeDAOImpl implements FraudeDAO {

	@Override
	public List<Fraude> GetHistoricoFraude() {

        //String sql = "SELECT * FROM tabela_exemplo WHERE campo = ?";
        String sql = "SELECT * FROM HISTORICO_FRAUDE";
        
        List<Fraude> fraudeList = new ArrayList<Fraude>();
        
        try (Connection conn = ConnectionManager.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            //stmt.setString(1, "valor");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Fraude fraude = new Fraude();
                    fraude.setCpf(rs.getString("cpf"));
                    fraude.setEntrada(rs.getString("entrada"));
                    fraude.setSaida(rs.getString("saida"));
                    fraude.setIdExecucao(rs.getString("id_execucao"));
                    fraude.setId(rs.getLong("id"));
                    fraudeList.add(fraude);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fraudeList;
	}

	@Override
	public void insertHistoricoFraude(Fraude fraude) {

	    // SQL para inserir os dados
	    String sql = "INSERT INTO OVER_HISTORICO_FRAUDE.HISTORICO_FRAUDE " +
	                 "(id, cpf, id_credito, entrada, saida, id_execucao, dt_expiracao, dt_criacao) " +
	                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

	    try (Connection conn = ConnectionManager.getInstance().getConnection();
	         PreparedStatement stmt = conn.prepareStatement(sql)) {

	        // Configurando os valores na consulta
	        stmt.setLong(1, fraude.getId());
	        stmt.setString(2, fraude.getCpf());
	        stmt.setString(3, fraude.getIdCredito());
	        stmt.setString(4, fraude.getEntrada());
	        stmt.setString(5, fraude.getSaida());
	        stmt.setString(6, fraude.getIdExecucao());
	        stmt.setObject(7, fraude.getDtExpiracao()); // java.time.LocalDateTime

	        // Executando a inserção
	        stmt.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	
}
