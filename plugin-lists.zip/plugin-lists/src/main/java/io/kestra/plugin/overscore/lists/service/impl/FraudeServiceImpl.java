package io.kestra.plugin.overscore.lists.service.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import io.kestra.plugin.overscore.lists.model.Fraude;
import io.kestra.plugin.overscore.lists.repository.FraudeRespository;
import io.kestra.plugin.overscore.lists.repository.impl.FraudeRespositoryImpl;
import io.kestra.plugin.overscore.lists.service.FraudeService;

@Component
public class FraudeServiceImpl implements FraudeService {
	
	private final FraudeRespository service = new FraudeRespositoryImpl();
	
	public List<Fraude> GetHistoricoFraude() {
		
		return service.GetHistoricoFraude();
	}
	

}
