package io.kestra.plugin.overscore.lists;

import java.util.List;

import io.kestra.core.models.annotations.Plugin;
import io.kestra.core.models.annotations.PluginProperty;
import io.kestra.core.models.tasks.RunnableTask;
import io.kestra.core.models.tasks.Task;
import io.kestra.core.runners.RunContext;
import io.kestra.plugin.overscore.lists.model.Fraude;
import io.kestra.plugin.overscore.lists.service.FraudeService;
import io.kestra.plugin.overscore.lists.service.impl.FraudeServiceImpl;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@ToString
@EqualsAndHashCode
@Getter
@NoArgsConstructor
@Schema(
    title = "Histórico de Fraude",
    description = "Plugin de consulta e registro de histórico"
)
@Plugin(
    examples = {
        @io.kestra.core.models.annotations.Example(
            title = "Detalhes do histórico de Fraude",
            code = {
                "cpf: cpf do cliente",
            	"idCredito: id do crédito",
            	"entrada: campos de entrada",
            	"registrarHistorico: identifica se será registrado o histórico. Só será registrado se não tiver expirado."
            }
        )
    }
)


public class HistoricoFraude extends Task implements RunnableTask<HistoricoFraude.Output> {
       @Schema(
            title = "cpf",
            description = "CPF do cliente"
        )
        @PluginProperty(dynamic = true) 
        @Builder.Default
        private String cpf = "";
    
       @Schema(
               title = "idCredito",
               description = "Id do Crédito"
           )
	    @PluginProperty(dynamic = true) 
	    @Builder.Default
	    private String idCredito = "";
	    
       @Schema(
               title = "registrarHistorico",
               description = "Flag que indica se iremos inserir o dado histórico. Por padrão ele fazer uma consulta."
           )
       
	    @PluginProperty(dynamic = true) 
	    @Builder.Default
	    private boolean registrarHistorico = false;
       

        @Override
        public HistoricoFraude.Output run(RunContext runContext) throws Exception {
        	
        	System.out.println("Executando: HistoricoFraude");
        	
        	if( runContext.namespaceKv("company.team").exists("KV_TESTE")) {
        		System.out.println("KV_TESTE: '" + runContext.namespaceKv("company.team").getValue("KV_TESTE").get().value() + "'");
        	}
          	
        	FraudeService service = new FraudeServiceImpl();
        	
        	List<Fraude> fraudeList = service.GetHistoricoFraude();
        	
            return Output.builder()
                .id(0)
                .saida("Teste Saída")
                .dataExpiracao("01/12/2025")
                .fraudeList(fraudeList)
                .build();
        }

        /**
         * Input or Output can be nested as you need
         */
        @Builder
        @Getter
        public static class Output implements io.kestra.core.models.tasks.Output {
            
            @Schema(
                title = "Id do historico gerado"
            )
            private final long id;
            
            @Schema(
                title = "saida do historico consultado ou gerado"
            )
            private final String saida;
            
            @Schema(
                title = "Data de expiração do historico"
            )
            private final String dataExpiracao;
            
            @Schema(
                 title = "Histórico de fraude"
                )
            private final List<Fraude> fraudeList;
        }
}