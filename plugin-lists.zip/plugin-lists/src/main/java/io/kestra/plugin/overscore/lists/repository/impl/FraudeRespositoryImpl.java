package io.kestra.plugin.overscore.lists.repository.impl;

import java.util.List;

import io.kestra.plugin.overscore.lists.dao.FraudeDAO;
import io.kestra.plugin.overscore.lists.dao.impl.FraudeDAOImpl;
import io.kestra.plugin.overscore.lists.model.Fraude;
import io.kestra.plugin.overscore.lists.repository.FraudeRespository;


public class FraudeRespositoryImpl implements FraudeRespository {

	private final FraudeDAO dao = new FraudeDAOImpl();
	
	@Override
	public List<Fraude> GetHistoricoFraude() {
		
		return dao.GetHistoricoFraude();
	}

	@Override
	public void insertHistoricoFraude(Fraude fraude) {
		dao.insertHistoricoFraude(fraude);
		
	}
	
	


}
