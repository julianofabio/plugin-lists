package io.kestra.plugin.overscore.lists.dao;

import java.util.List;

import io.kestra.plugin.overscore.lists.model.Fraude;

public interface FraudeDAO {

	List<Fraude> GetHistoricoFraude();

    void insertHistoricoFraude(Fraude fraude);
	
}
