package io.kestra.plugin.overscore.lists.service;

import java.util.List;

import io.kestra.plugin.overscore.lists.model.Fraude;

public interface FraudeService {

	List<Fraude> GetHistoricoFraude() ;
}
