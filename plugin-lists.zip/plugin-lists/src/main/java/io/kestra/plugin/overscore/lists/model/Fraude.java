package io.kestra.plugin.overscore.lists.model;
	
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
	
@Data // Gera todos os Getter e Setter
@AllArgsConstructor // Gera o construtor com todos os argumentos
@NoArgsConstructor // Gera o construtor sem os argumentos
@Entity
public class Fraude {
	
	@Id
    private Long id;
    
    private String cpf;
    
    private String idCredito;
    
    private String entrada;
    
    private String saida;
    
    private String idExecucao;

    private java.time.LocalDateTime dtExpiracao;

    private java.time.LocalDateTime dtCriacao;
}