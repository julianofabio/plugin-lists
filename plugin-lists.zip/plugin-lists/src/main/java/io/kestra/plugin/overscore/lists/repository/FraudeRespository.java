package io.kestra.plugin.overscore.lists.repository;

import java.util.List;

import io.kestra.plugin.overscore.lists.model.Fraude;

public interface FraudeRespository {
	
	List<Fraude> GetHistoricoFraude() ;
	
	void insertHistoricoFraude(Fraude fraude);

}
